# Chill-cast Android app (from chill-cast-app-v3)

This project wraps the existing Chill-cast music player in Capacitor. It keeps local-file playback and local playlists, adds online search using the Apple iTunes Search API (short preview clips only), and provides Firebase email/password login plus Firestore playlist metadata sync.

## Important limits
- iTunes search returns short previews, not full songs. For full online streaming, connect a licensed music provider/API that permits playback in your app.
- Audio files imported from the phone remain on that phone and are not uploaded. Cloud sync stores playlist names and track IDs/references only; local-file tracks themselves will not play on a different device unless that device has the same files.
- Firebase credentials are not included. Login and cloud sync remain disabled until you configure your own Firebase project.
- This project has not been compiled/tested into an APK in this environment. Build it using the steps below.

## 1. Firebase setup (free tier available)
1. Open https://console.firebase.google.com/ and create a project.
2. Add a Web app and copy its web configuration into `firebase-config.js`, replacing every placeholder.
3. In Firebase Console, open **Authentication → Sign-in method** and enable **Email/Password**.
4. Create a **Cloud Firestore** database.
5. In Firestore Rules, use the following per-user rules for the `users/{uid}/playlists/{playlistId}` path (review before public release):

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid}/playlists/{playlistId} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

6. Keep `firebase-config.js` in the app source; never put Firebase Admin/service-account keys in a client app. Enable email verification and password recovery before distributing publicly.

## 2. Build on a computer
You cannot build an Android APK directly from the phone using this repository alone. Use a computer with Node.js LTS, Android Studio, and Android SDK installed.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio, allow Gradle sync and install the required SDK components. Then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio shows a link to the APK when finished. For later changes run `npm run build` and `npx cap sync android` again before rebuilding.

## 3. Test checklist
- Add a local MP3 and test play/pause/seek/next/previous.
- Search an artist in Online and test a preview; internet is required.
- Configure Firebase, create an account, create/rename a playlist, then sign in on another device and check cloud metadata.
- Test Android back navigation, screen lock, Bluetooth/headset controls, and battery restrictions. Background playback/media notifications can vary by Android version and may need a native media-session plugin for reliable production behavior.

## Project structure
- `index.html`: original player plus Online search and account UI
- `cloud-auth.js`: Firebase Authentication and Firestore playlist sync
- `firebase-config.js`: your Firebase web config placeholders
- `capacitor.config.json`: Android wrapper settings
- `package.json`: Capacitor and Vite build dependencies

## 4. If you only have an Android phone (cloud build)
A full native APK build needs Android SDK/Gradle, so the easiest phone-only route is GitHub Actions:
1. Extract this ZIP on your phone.
2. Create a new GitHub repository in your browser.
3. Upload the extracted project files/folders to the repository root (including the `.github/workflows` folder). If GitHub's mobile upload flow cannot upload hidden folders, create `.github/workflows/build-android.yml` in GitHub using the workflow file included in this project.
4. If you want login/cloud sync, edit `firebase-config.js` in GitHub and replace the placeholders first.
5. Open the repository's **Actions** tab, select **Build Chill-cast Android APK**, and tap **Run workflow**.
6. When the workflow completes successfully, open that run, scroll to **Artifacts**, and download `chill-cast-debug-apk`. Extract it and install `app-debug.apk` on your Android phone. You may need to allow installation from your browser/file manager.
7. If the workflow fails, open the failed step and read its error log; common causes are missing project files or invalid Firebase config syntax.

The first build may take several minutes. A debug APK is suitable for personal testing; publishing to Google Play requires a properly signed release build and store-policy checks.
