import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js';
import { getAuth, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js';
import { getFirestore, collection, doc, getDocs, setDoc, deleteDoc, serverTimestamp } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js';
import { firebaseConfig } from './firebase-config.js';

const $ = id => document.getElementById(id);
const sheet = $('authSheet');
let auth = null, db = null, user = null, createMode = false, enabled = false;
const configured = firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith('PASTE_') && firebaseConfig.projectId && !firebaseConfig.projectId.startsWith('YOUR_');
function message(t){ $('authMessage').textContent = t; }
function setMode(create){ createMode=create; $('authTitle').textContent=create?'Create your Chill-cast account':'Sign in to Chill-cast'; $('authSubmit').textContent=create?'Create account':'Sign in'; $('authMode').textContent=create?'I already have an account':'Create account'; $('authPassword').autocomplete=create?'new-password':'current-password'; }
function status(){ $('accountState').textContent=user?`Signed in: ${user.email}`:'Cloud playlists'; $('accountHint').textContent=user?'Playlist sync enabled':'Sign in to sync playlists'; $('accountOpen').textContent=user?'Account':'Sign in'; $('authLogout').hidden=!user; }
$('accountOpen').addEventListener('click',()=>{sheet.hidden=false;setMode(!user);message(configured?'':'Setup required: add your Firebase config in firebase-config.js.');});
$('authClose').addEventListener('click',()=>sheet.hidden=true);
sheet.addEventListener('click',e=>{if(e.target===sheet)sheet.hidden=true;});
$('authMode').addEventListener('click',()=>setMode(!createMode));
$('authForm').addEventListener('submit',async e=>{
  e.preventDefault();
  if(!enabled){message('Firebase is not configured yet. Follow README.md setup steps first.');return;}
  const email=$('authEmail').value.trim(), password=$('authPassword').value;
  $('authSubmit').disabled=true;message('Please wait…');
  try { if(createMode) await createUserWithEmailAndPassword(auth,email,password); else await signInWithEmailAndPassword(auth,email,password); message('Account ready.'); sheet.hidden=true; }
  catch(err){message((err.code||'auth/error').replace('auth/','').replaceAll('-',' ')+'. Please check your email/password and Firebase settings.');}
  finally{$('authSubmit').disabled=false;}
});
$('authLogout').addEventListener('click',async()=>{if(auth)await signOut(auth);sheet.hidden=true;});
window.cloudSyncList = async list => { if(!user||!db||!list?.id)return; try { await setDoc(doc(db,'users',user.uid,'playlists',list.id),{id:list.id,name:list.name,songIds:list.songIds||[],created:list.created||Date.now(),updatedAt:serverTimestamp()}); } catch(e){ console.warn('Cloud playlist sync failed',e); } };
window.cloudDeleteList = async id => { if(!user||!db||!id)return; try { await deleteDoc(doc(db,'users',user.uid,'playlists',id)); } catch(e){ console.warn('Cloud playlist delete failed',e); } };
async function loadCloudLists(){ if(!user||!db)return; try { const snap=await getDocs(collection(db,'users',user.uid,'playlists')); window.chillCastApplyCloudLists?.(snap.docs.map(d=>d.data()));
    // Upload local playlists that are not yet in the account.
    const remoteIds=new Set(snap.docs.map(d=>d.id));
    for(const item of (window.chillCastGetLists?.()||[])){if(!remoteIds.has(item.id))await window.cloudSyncList(item);} } catch(e){ message('Could not load cloud playlists. Check Firestore rules.'); } }
if(configured){
 try { const app=initializeApp(firebaseConfig); auth=getAuth(app); db=getFirestore(app); enabled=true; onAuthStateChanged(auth,async next=>{user=next;status();if(user)await loadCloudLists();}); }
 catch(e){message('Firebase setup error. Check firebase-config.js.');}
}
status();
