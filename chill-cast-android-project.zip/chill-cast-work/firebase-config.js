// 1) Create a Firebase project at https://console.firebase.google.com/
// 2) Add a Web app and paste its config values below.
// 3) Enable Authentication > Email/Password and create a Firestore database.
// Keep this file private to your own app deployment; never paste service-account keys here.
export const firebaseConfig = {
  apiKey: "PASTE_YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "PASTE_YOUR_MESSAGING_SENDER_ID",
  appId: "PASTE_YOUR_FIREBASE_APP_ID"
};
